<?php
	include_once('../connection/PDO_db_function.php');
	$db = new DB_Functions(); 
	
	$id = $_REQUEST['p'];
	
	//echo 'ID:'.$id;
    $user = $db->where('*','mv_user','mv_user_id',$id);
    $user = $user[0];
    
    $wallet = $db->where('*','mv_wallet','mv_user_id',$id);
    $wallet = $wallet[0];
	
    
?>
    <link href="css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
<div class="modal-header">
	<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
	<h4 class="modal-title">Edit User</h4>
	
</div>


<div class="modal-body">
	
	<div class="row">
		<div class="col-lg-12 ">
			
			<form role="form" id="form_edit" action="soap_func.php?type=edituser&tb=user" method="post" enctype="multipart/form-data">
				<input type="hidden" name="token" value="<?php echo $token; ?>" />
				<div class="hr-line-dashed"></div>
				<?php
					$gettype = $db->where('*','mv_user_type','mv_user_type_id',1);
					$gettype = $gettype[0];
					$type=$gettype['mv_user_type_name'];
					
					$gettype2 = $db->where('*','mv_user_type','mv_user_type_id',2);
					$gettype2 = $gettype2[0];
					$type2=$gettype2['mv_user_type_name'];
					
					$key = 'mumuls1314';
					
					$encpass = $user['mv_user_pword'];
					$data = base64_decode($encpass);
					$iv = substr($data, 0, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));
					
					$decpass = rtrim(
					mcrypt_decrypt(
					MCRYPT_RIJNDAEL_128,
					hash('sha256', $key, true),
					substr($data, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC)),
					MCRYPT_MODE_CBC,
					$iv
					),
					"\0"
					);
					
					
				?>
				<div class="form-group"><label>Username</label> <input type="text" placeholder="Enter username" class="form-control" name="uname" id="chkuser_ajax"  value="<?php echo $user["mv_user_name"]; ?>"></div>
				<div class="form-group"><label>Change password? :</label>&nbsp;  &nbsp;<input style="transform: scale(1.9)" type="checkbox" id="myCheck"  onclick="myFunction()" name="checkpass" value="checked"></div>
				<div id="text" style="display:none">
				     
				    <div class="form-group"><label>New Password</label> <input type="text" placeholder="Enter password" class="form-control" name="password" id="checkpassword" value="<?php echo $decpass; ?>">  </div>
				    <div class="form-group"><label>Confirm Password</label> <input type="text" placeholder="Enter password" class="form-control" name="cpassword" value="<?php echo $decpass; ?>"></div>
				    
				</div> 
				
				
				<div class="form-group"><label>Fullname</label> <input type="text" placeholder="Enter fullname" class="form-control" name="fname"  value="<?php echo $user["mv_user_fullname"]; ?>"></div>
				<div class="form-group"><label>Email</label> <input type="email" placeholder="Enter email" class="form-control" name="email"  value="<?php echo $user["mv_user_email"]; ?>"></div>
				
				
				<div class="form-group"><label>Type <span class="text-danger">(Please make user your user type is correct!)</span></label>
					<div class="row">
						<div class="i-checks col-md-3 text-center"><input type="radio" name="typeid" value="1"  <?php if ($user["mv_user_type"] == 1): ?>
							checked="checked"
						<?php endif ?>> <?php echo $type; ?></div>
						<div class="i-checks col-md-3 text-center"><input type="radio" name="typeid" value="2"  <?php if ($user["mv_user_type"] == 2): ?>
							checked="checked"
						<?php endif ?>/> <?php echo $type2; ?></div>
					</div>
				</div>
				
					<div class="form-group"><label>Status </label>
					<div class="row">
						<div class="i-checks col-md-3 text-center"><input type="radio" name="ustatus" value="1"  <?php if ($user["mv_user_status"] == 1): ?>
							checked="checked"
						<?php endif ?>/>Unblock</div>
						<div class="i-checks col-md-3 text-center"><input type="radio" name="ustatus" value="0"  <?php if ($user["mv_user_status"] == 0): ?>
							checked="checked"
						<?php endif ?>/>Block</div>
					</div>
				</div>
				
				<div class="form-group"><label>Credit Amount</label> <input type="number" placeholder="Enter credit" class="form-control" name="credit"  value="<?php echo $wallet["mv_wallet_amt"]; ?>"></div>
				<div class="form-group"><label>NRIC</label> <input type="text" placeholder="eg. 931120-06-5555" class="form-control" name="ic"  value="<?php echo $user["mv_user_ic"]; ?>"></div>
				<div class="form-group"><label>Phone Number</label> <input type="text" placeholder="eg. XXX-XXXXXXX" class="form-control" name="phone"  value="<?php echo $user["mv_user_phnum"]; ?>"></div>
				
				
				
				
				<div class="form-group"><label>Photo</label> 
					<div class="custom-file ">
						<input  type="file"  id="myfile" class="custom-file-input" name="file" accept=".jpg, .png , .jpeg , .tiff"  value="<?php echo $user["mv_user_image"]; ?>" >
						<label for="logo" class="custom-file-label">Choose file...</label>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
					<button type="submit" class="btn btn-white" name="btnsubmituser" value="<?php echo $user["mv_user_id"]; ?>">Submit</button>
					
					
				</div>
			</form>
		</div>
		
	</div>
</div>
<script src="js/plugins/iCheck/icheck.min.js"></script>
        <script>
            $(document).ready(function () {
                $('.i-checks').iCheck({
                    checkboxClass: 'icheckbox_square-green',
                    radioClass: 'iradio_square-green',
                });
            });
            
            function myFunction() {
                var checkBox = document.getElementById("myCheck");
                var text = document.getElementById("text");
                if (checkBox.checked == true){
                    text.style.display = "block";
                } else {
                   text.style.display = "none";
                }
            }
            
            //for username checked ajax
        		$('#chkuser_ajax').change(function(){
        		var userid = $(this).val();
        		var thisparent = $(this).parent();
        		if(userid == ""){
        			$('#user_note').remove();
        		}else{
        			$('#user_note').remove();
        			$.post('api/validation.php', { user_id: userid, type: 'check_user_ajax' }, function(data){
        				console.log(data);
        				data = JSON.parse(data);
        				if(data.Status){
        					thisparent.append('<br><label id="user_note" class="text-success">'+data.Msg+'</label>');
        				}else{
        					thisparent.append('<label id="user_note" class="text-danger">'+data.Msg+'</label>');
        				}
        			});
        		}
        	});
            
            $(document).ready(function(){
			
			$('#form_edit').validate({
				rules: {
					password: {
					        required: true,
							minlength: 6
					},
					cpassword: {
						required: true,
						minlength: 6,
                        equalTo: "#checkpassword"
					},
					phone: {
						required: true,
						phone: true
					},
					email: {
						required: true,
						email: true
					},
					uname: {
						required: true,
						minlength: 6,
					
						
					},
					
					ic:{
					    required: true,
					    number:true,
					    
					},
					fname: {
						required: true,
						minlength: 3,
						
					},
					
					credit: {
					       min: 0,
                            required: true,
					},
					
					phone:{
					    required: true,
					    number:true
					}
				
				
				},
				messages: {
					uname: {
						required: "Please enter a username",
						minlength: "Your username must consist of at least 6 characters",
						
					       },
				    password: {
						required: "Please enter a password",
						minlength: "Your username must consist of at least 6 characters",
						
					},
					cpassword: {
						required: "Please enter a  confirm password",
						minlength: "Your username must consist of at least 6 characters",
						
					},
						credit: {
					       min: "Your amount cannot be less than 0.",
					     
					},
						ic:{
					    required: "Please enter IC number",
					    regex: "Please enter a valid ICnumber"
					},
						phone:{
					    required: "Please enter a phone number",
				        pattern: "Please enter a valid phone number"
					},
				}
			});
		
			
		
			
		
			
			
		});
		
</script>

