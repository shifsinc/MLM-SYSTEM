<?php
include_once('../connection/PDO_db_function.php');
	$db = new DB_Functions(); 
	
	$id = $_REQUEST['p'];
	
	//echo 'ID:'.$id;
	$tb = 'mv_order JOIN mv_user ON mv_order.mv_user_id=mv_user.mv_user_id JOIN mv_package ON mv_package.mv_package_id=mv_order.mv_package_id';
    $order = $db->where('*',$tb,'mv_order_id',$id);
    $order = $order[0];

    
?>
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
<h4 class="modal-title">Order Details</h4>

</div>
<div class="modal-body">


    <div class="ibox-content">
    	<div class="col-lg-12">
    		<div class="contact-box ">
			
		    	<h2 class="m-b-xs"><strong><?php echo $order["mv_package_name"]; ?></strong></h2>
			

		    	<br>
		        	<table class="table">
		        	    
    			    	<thead>
    			    	</thead>
    			    	
    			    	<tbody>
    			    	    
    			    	    
        					<tr>
            					<td>Order User</td>
            					<td><?php echo $order["mv_user_fullname"]; ?></td>
            				</tr>
            				<tr>
            					<td>User Address</td>
            					<td><?php echo $order["mv_order_addr"]; ?></td>
            				</tr>
            				<tr>
            					<td>Date</td>
            					<td><?php echo $order["mv_order_date"]; ?></td>
            				</tr>
            				<tr>
            					<td>Price</td>
            					<td><?php echo $order["mv_package_price"]; ?> <span class="badge badge-danger">V-Coins</span></td>
            				</tr>
            				<tr>
            					<td>Package Points</td>
            					<td><?php echo $order["mv_package_point"]; ?></td>
            				</tr>
            				<?php
    						    
    						    $status = $order["mv_order_status"];
    						    if($status == 0)
    						    {
    						        $show = "Pending";
    						        $color = " text-danger";
    						    }else if($status == 1)
    						    {
    						        $show = "Approved";
    						        $color = " text-warning";
    						    }else if($status == 2)
    						    {
    						        $show = "Delivered";
    						        $color = " text-info";
    						    }else if($status == 3)
    						    {
    						        $show = "Cancelled";
    						        $color = " text-dark";
    						    }
    						
    						?>
							

                            <tr>
            					<td>Status</td>
            					<td class="<?php echo $color; ?>"><?php echo $show; ?></td>
            				</tr>
        		
            			
        						<tr>
        							<td></td>
        							<td></td>
        						</tr>
						</tbody>
						
					</table>	
					<div class="table-responsive m-t">
                        <table class="table invoice-table">
                            <thead>
								<tr>
									<th>Item List</th>
									<th>Quantity</th>
									<th>Unit</th>
									
									<th>Total Unit</th>
								</tr>
							</thead>
                            <tbody>
								
								
								<?php 
								    
								    
								    
								    $i=1;
								    $totalunit = 0;
									$tb = 'mv_order_item JOIN mv_order ON mv_order_item.mv_order_id=mv_order.mv_order_id';
									$result = $db->where('*',$tb,'mv_order_item.mv_order_id',$id);
									foreach($result as $row){
								
								?>
								
								
								<tr>
								    
								    <?php 
								        $itemid = $row["mv_item_id"];
								        $item = $db->where('mv_item_name, mv_item_desc','mv_item','mv_item_id',$itemid);
								        $item = $item[0];
								    ?>
								    
									<td><div><strong><?php echo $item["mv_item_name"]; ?></strong></div>
									<small><?php echo $item["mv_item_desc"]; ?></small></td>
									<td><?php echo $row["mv_order_item_qty"]; ?></td>
									
									
									<td><?php echo $row["mv_order_item_unit"]; ?></td>
									<?php 

									    $total =  $row["mv_order_item_qty"] * $row["mv_order_item_unit"]; 

									?>
									<td><?php echo $total; ?></td>
								</tr>
								
								<?php
								    
								    $totalunit = $totalunit + $total;
							    	$i++; 
								
								} ?>
								
								
								
							</tbody>
						</table>
					</div>
                    <table class="table invoice-total">
                        <tbody>
						    <tr>
    							<td><strong>Package Max Unit</strong></td>
    							<td><?php echo $order["mv_order_unit"]; ?> <small>UNITS</small</td>
							</tr>
							<tr>
								<td><strong>Your Total Units</strong></td>
								<td><?php echo $totalunit; ?> <small>UNITS</small</td>
							</tr>
							<tr>
								<td><strong>V-Coins :</strong></td>
								<td><?php echo $order["mv_order_price"]; ?> <small>POINTS</small></td>
							</tr>
						</tbody>
					</table>
				
					
				</div>
			</div>
		</div>
		
		
	</div>
	<div class="modal-footer">
		<button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
		
	</div>