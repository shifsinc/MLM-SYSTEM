<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome! Future Home of Another Amazing Website Powered by Exabytes</title>
        <link rel="shortcut icon" href="https://welcome.exabytes.my/images/exa-favicon.ico" />
    </head>

    <body style="margin:0px;">
        <iframe src="https://welcome.exabytes.my/include/content.php" width="100%" height="100%" style="border:0px;"></iframe>
    </body>
</html>
